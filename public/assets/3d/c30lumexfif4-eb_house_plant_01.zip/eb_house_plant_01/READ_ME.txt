NOT FOR COMMERCIAL USE

*   *   *   *   *

House Plant 01
eb_house_plant_01

House Plant 01 made to be used within Unreal. Materials PBR compliant. Great for use in a game or architectural render. For more details or questions feel free to contact me. 

DETAILS:
- Tri Count: 602
- Color Map: eb_house_plant_01_c
- Roughness Map: Packed in RED channel of eb_house_plant_01_g
- Metal Map: Packed in GREEN channel of eb_house_plant_01_g
- Opacity Mask: Packed in BLUE channel of eb_house_plant_01_g
- Normal Map: eb_house_plant_01_n

*   *   *   *   *

For questions contact Ernesto at ernestbezera@gmail.com